
using System;

public class HelloWorld
{
     static void Main(string[] args)
    {
        int[] arr = { 1,1,2,4,5,6,6,6,7,7,8,8,8,8,8,9,9,9,2,1,8,8,8,8,8,8,8,8,1,1,2,2,2 };

        int oldNumber = arr[0];
        int newNumber;
        int oldLength = 1;
        int newLength = 1;
        int maxLength = 1;

        for (int i = 1; i < arr.Length; i++)
        {
            newNumber = arr[i];

            if (newNumber != oldNumber)
            {
                oldNumber = newNumber;
                oldLength = newLength;
                newLength = 1;
            }
            else
            {
                newLength++;
            }
            maxLength = Math.Max(maxLength, newLength);
        }

        Console.WriteLine("Максимальная длина подмассива с одинаковыми числами: " + maxLength);
    }
}